# Modifications

## mediaelement-and-player.js

*<https://github.com/mediaelement/mediaelement/blob/7.0.7/build/mediaelement-and-player.js>*

Contains the following PRs that may or may not be currently part of the master branch.

* svg4everyone remove define variable for umd header: <https://github.com/mediaelement/mediaelement/pull/2969>
* Remove fullscreen fix for Chrome version <17. Original issue: <https://github.com/adaptlearning/adapt-contrib-media/issues/255> Applies fix from <https://github.com/mediaelement/mediaelement/pull/2971>
