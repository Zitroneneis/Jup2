import TooltipView from 'core/js/views/TooltipView';

const tooltips = new TooltipView();
export default tooltips;
