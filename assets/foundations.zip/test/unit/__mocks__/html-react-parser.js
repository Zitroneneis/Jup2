module.exports = window.require('html-react-parser');
