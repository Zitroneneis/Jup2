module.exports = {
  parse: function() {
    const config = {
      browser: {
        name: '',
        version: ''
      },
      os: {
        name: '',
        version: ''
      },
      engine: {
        name: '',
        version: ''
      },
      platform: {
        name: '',
        version: ''
      }
    };
    return config;
  }
};
