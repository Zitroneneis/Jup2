module.exports = window.require('backbone');
