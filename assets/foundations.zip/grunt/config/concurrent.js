module.exports = {
  server: ['connect:server'],
  'server-silent': ['connect:server-silent'],
  spoor: ['connect:spoorOffline']
};
